from loguru import logger
import os

LOG_DIR = "logs"

if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

logger.add(f"{LOG_DIR}/bot.log", rotation="10 MB")

def get_logger():
    return logger
