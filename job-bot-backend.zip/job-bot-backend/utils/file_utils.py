import os
import uuid

def create_local_path(dir_path: str, extension=".docx"):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    filename = f"{uuid.uuid4()}{extension}"
    return os.path.join(dir_path, filename)
