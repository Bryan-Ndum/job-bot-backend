def detect_job_domain(description: str) -> str:
    desc = description.lower()

    if any(k in desc for k in ["soc", "siem", "security", "threat", "incident", "ddos"]):
        return "cyber"

    if any(k in desc for k in ["help desk", "desktop", "it support", "troubleshoot"]):
        return "it"

    if any(k in desc for k in ["software", "developer", "engineer", "backend", "frontend"]):
        return "swe"

    if any(k in desc for k in ["aws", "azure", "cloud", "gcp", "devops"]):
        return "cloud"

    if any(k in desc for k in ["data", "analytics", "sql", "python", "ml"]):
        return "data"

    return "hybrid"
