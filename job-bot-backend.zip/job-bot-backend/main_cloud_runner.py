import asyncio
import os
from dotenv import load_dotenv

from supabase_client import get_supabase
from utils.logger import get_logger
from job_scanner import scan_jobs
from match_engine import compute_match_score
from resume_engine import generate_resume
from cover_letter_engine import generate_cover_letter
from apply_engine import apply_to_job

load_dotenv()
logger = get_logger()

SCAN_INTERVAL = int(os.getenv("BOT_SCAN_INTERVAL_SECONDS", 600))  # 10 minutes
MATCH_THRESHOLD = int(os.getenv("BOT_MATCH_SCORE_THRESHOLD", 70))

async def main_loop():
    sb = get_supabase()
    logger.info("🚀 Cloud Job Bot Started!")

    while True:
        try:
            logger.info("🔍 Scanning for jobs...")
            jobs = await scan_jobs()  

            for job in jobs:
                score = compute_match_score(job)
                if score < MATCH_THRESHOLD:
                    continue

                logger.info(f"🔥 Match {score}% — Applying to {job['title']} at {job['company']}")

                resume_path = generate_resume(job)
                cover_path = generate_cover_letter(job)

                await apply_to_job(job, resume_path, cover_path)

                sb.table("applications").insert({
                    "company": job["company"],
                    "job_title": job["title"],
                    "job_url": job["url"],
                    "match_score": score,
                    "resume_version": job["domain"],
                    "cover_letter_version": job["domain"],
                }).execute()

            logger.info(f"⏳ Sleeping {SCAN_INTERVAL} seconds...")
            await asyncio.sleep(SCAN_INTERVAL)

        except Exception as e:
            logger.error(f"❌ ERROR: {e}")
            sb.table("error_logs").insert({
                "context": "main_loop",
                "message": str(e),
            }).execute()
            await asyncio.sleep(30)

if __name__ == "__main__":
    asyncio.run(main_loop())
