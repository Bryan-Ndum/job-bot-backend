import asyncio
from main_cloud_runner import main_loop

if __name__ == "__main__":
    print("🖥 Running bot locally...")
    asyncio.run(main_loop())
